<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var common\models\VVillageFives $model */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'V Village Fives', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="vvillage-fives-view">



</div>
